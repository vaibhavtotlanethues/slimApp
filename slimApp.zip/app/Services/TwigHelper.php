<?php

namespace App\Services;

use JtmSdk\Services\LocationService;
use Odan\Session\SessionInterface;
use Psr\Container\ContainerExceptionInterface;
use Psr\Container\ContainerInterface;
use Psr\Container\NotFoundExceptionInterface;
use Twig\TwigFilter;
use Twig\TwigFunction;

/**
 * Class TwigHelper
 *
 * @package App\Services
 */
class TwigHelper
{
    protected SessionInterface $session;
    protected LocationService  $locationService;

    /**
     * @throws ContainerExceptionInterface
     * @throws NotFoundExceptionInterface
     */
    public function __construct(ContainerInterface $container)
    {
        /** @var SessionInterface $session */
        $this->session = $container->get(SessionInterface::class);

        /** @var LocationService $locationService */
        $this->locationService = $container->get(LocationService::class);
    }

    /**
     * @return TwigFunction
     */
    public function baseUrl(): TwigFunction
    {
        $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (int)$_SERVER['SERVER_PORT'] === 443;
        $http     = $isSecure ? 'https://' : 'http://';
        $url      = $http . $_SERVER['SERVER_NAME'];

        return new TwigFunction('baseUrl', static function () use ($url) {
            return $url;
        });
    }

    /**
     * @return TwigFunction
     */
    public function isProd(): TwigFunction
    {
        $appEnv = $_ENV['APP_ENV'];
        return new TwigFunction('isProd', static function () use ($appEnv) {

            return $appEnv === 'prod';
        });
    }

    /**
     * @return TwigFunction
     */
    public function cssFile(): TwigFunction
    {
        $uri = $_SERVER['REQUEST_URI'];

        return new TwigFunction('cssFile', static function ($isPlateIndexRoute) use ($uri) {
            $uriExplode = explode('/', $uri);
            $checkFor   = ['privacy-policy', 'terms-services', 'contact'];

            if ($isPlateIndexRoute || !empty(array_intersect($checkFor, $uriExplode))) {
                return 'plate';
            }

            return 'main';
        });
    }

    /**
     * @return TwigFilter
     */
    public function ucwords(): TwigFilter
    {
        return new TwigFilter('ucwords', static function ($data) {
            return ucwords($data);
        });
    }

    /**
     * @param $settings
     *
     * @return TwigFunction
     */
    public function viewBasePath($settings): TwigFunction
    {
        $splitTest = $settings['splitTest'];
        return new TwigFunction('viewBasePath', static function () use ($splitTest) {
            return "";
        });
    }

    /**
     * @return TwigFunction
     */
    public function phone(): TwigFunction
    {
        $phone = $_ENV['PHONE'];
        return new TwigFunction('phone', static function () use ($phone) {
            return $phone;
        });
    }
    /**
     * @return TwigFunction
     */
    public function contactEmail(): TwigFunction
    {
        $contactEmail = $_ENV['CONTACT_EMAIL'];
        return new TwigFunction('contactEmail', static function () use ($contactEmail) {
            return $contactEmail;
        });
    }

    /**
     * @return TwigFunction
     */
    public function dynamicData(): TwigFunction
    {
        $session         = $this->session;
        $locationService = $this->locationService;
        $queryString     = $_SERVER['QUERY_STRING'] ?? '';

        return new TwigFunction('dynamicData', static function ($key = null) use ($session, $queryString, $locationService) {
            $plateFunnel = $session->get('funnelType') === "plateFunnel";
            $resp        = $locationService->getQueryStringLocation($queryString);
            $data        = $session->get('dynamicData');

            if (!$data) {
                $jtmDefaultLocation = $locationService->getDefaultLocation();
                $location           = $locationService->getCloudFrontLocation();

                $data = strtolower($location['countryName']) === 'united states' ? $location : $jtmDefaultLocation;
            }

            $data['title'] = $plateFunnel ? 'Official Vehicle History Records' : $data['title'];

            $stateName        = null;
            $stateLink        = null;
            $defaultStateName = str_replace(' ', '', ucwords($data['stateName']));

            if (($resp['state'] && $resp['stateName']) || $resp['location']) {
                $stateLink         = $resp['stateName'] ? str_replace(' ', '', ucwords($resp['stateName'])) : $defaultStateName;
                $data['stateLink'] = $stateLink;
                $data['state']     = $resp['state'] ?? $data['state'];
                $stateName         = strtoupper($stateLink) ?? strtoupper($data['stateName']);
                $data['stateName'] = $stateName;
                $data['title']     = $resp['location'] ?? $data['title'];
                $session->set('dynamicData', $data);
            }

            if ($session->get('plateNumberState')) {
                $stateLink = str_replace(' ', '', ucwords($session->get('plateNumberState')));
                $stateName = strtoupper($stateLink);

                $data['stateName'] = $stateName;
                $data['stateLink'] = $stateLink;
            }

            if ($key) {
                return $data[$key] ?? null;
            }

            return $data;
        });
    }

}
