<?php

use App\Services\TwigHelper;
use DI\Container;
use Psr\Container\ContainerInterface;

/** @var ContainerInterface $container */
$app = $app ?? null;

/** @var Container $container */
$container = $app->getContainer();

try {
    $twigHelper = new TwigHelper($container);

    $twig    = $twig ?? null;
    $twigEnv = $twig->getEnvironment();

    $twigEnv->addFunction($twigHelper->baseUrl());
    $twigEnv->addFunction($twigHelper->isProd());
    $twigEnv->addFunction($twigHelper->cssFile());
    $twigEnv->addFilter($twigHelper->ucwords());
    $twigEnv->addFunction($twigHelper->viewBasePath($container->get('settings')));
    $twigEnv->addFunction($twigHelper->dynamicData());
    $twigEnv->addFunction($twigHelper->phone());
    $twigEnv->addFunction($twigHelper->contactEmail());
} catch (NotFoundExceptionInterface|ContainerExceptionInterface $e) {
    var_dump($e->getMessage());
}
