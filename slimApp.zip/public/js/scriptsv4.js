/**
 * @param name
 * @returns {boolean}
 */
function validateForm (name) {
  const formEl = document.querySelector(`#${name}`)
  const inputs = formEl.querySelectorAll('[data-error]')

  for (const input of inputs) {
    const { value, dataset } = input

    if (trim(value) === '') {
      alert(dataset.error)

      return false
    }
  }

  return true
}

/**
 * @param value
 * @returns {*}
 */
function trim (value) {
  return value.replace(/^\s+|\s+$/g, '')
}

/**
 * @param prefix
 * @param input
 * @returns {boolean}
 */
function showError (input, errorMsg) {
  const inputField = document.getElementById(input)
  alert(errorMsg)
  inputField.focus()
}

function checkCompleteOrderBilling () {
  const billingForm = document.formCompleteOrder
  const firstName = billingForm.firstName
  const cardNumber = billingForm.cardNumber
  const cardCvvNo = billingForm.cardCvvNo
  const zipCode   = billingForm.zipCode
  const splitTest = billingForm.splitTest
  const validateLastName = splitTest.value === '0' || splitTest.value === '2';
  const isCCErrorExists = document.getElementById('isCCErrorExists');
  const errorDiv = document.getElementById('ccErrorDiv');
  const ccErrorMsg = errorDiv.innerHTML;

  if (!validateName(firstName.value)) {
    firstName.focus()
    return false
  }

  if (validateLastName && !validateName(billingForm.lastName.value, 'last')) {
    billingForm.lastName.focus()
    return false
  }

  if (!validateCreditCardNumber(cardNumber.value)) {
    cardNumber.focus()
    return false
  }

  if (!validateCcExpiration(billingForm.expMonth.value, billingForm.expYear.value)) {
    billingForm.expMonth.focus()
    return false
  }
  if (!validateCVV(cardCvvNo.value)) {
    cardCvvNo.focus()
    return false
  }
  if (!validateEmail(billingForm.email.value)) {
    billingForm.email.focus()
    return false
  }

  if (isCCErrorExists.value === 'yes' && ccErrorMsg === 'Prepaid cards not accepted, please try different card') {
    alert('Card type not accepted, please try a different card.');
    return false;
  }

  if (isCCErrorExists.value === 'yes') {
    return false
  }
}

function validateEmail (mail) {
  let regex = new RegExp('([!#-\'*+/-9=?A-Z^-~-]+(\.[!#-\'*+/-9=?A-Z^-~-]+)*|"\(\[\]!#-[^-~ \t]|(\\[\t -~]))+")@([!#-\'*+/-9=?A-Z^-~-]+(\.[!#-\'*+/-9=?A-Z^-~-]+)*|\[[\t -Z^-~]*])')

  if (regex.test(mail)) {
    return true
  }
  let msg = mail === '' ? 'Please enter your email address' : 'You have entered an invalid email address!';
  alert(msg);
  return false
}

function validateName (cus_name, type = 'first') {
  cus_name = trim(cus_name)

  if (cus_name === '') {
    alert('Please enter your ' + type + ' name.')
    return false
  } else if (cus_name.length > 32) {
    alert(type + ' name cannot be more than 32 characters')
    return false
  } else {

    const iChars = '?1234567890'
    for (let i = 0; i < cus_name.length; i++) {
      if (iChars.indexOf(cus_name.charAt(i)) !== -1) {
        alert('Numeric values does not allow in ' + type + ' name.')
        return false
      }
    }
  }

  return true
}

function validateCreditCardNumber (cardNumber) {
  cardNumber = trim(cardNumber)
  if (cardNumber !== '') {
    const len = cardNumber.length
    const iChars = '0123456789 '

    for (let i = 0; i < len; i++) {
      if (iChars.indexOf(cardNumber.charAt(i)) === -1) {
        alert('Only numeric values are allowed in Card Number.')
        return false
      }
    }

    if (len !== 19 && len !== 16) {
      return false
    }

  } else {
    return false
  }

  return true
}

function validateCVV (cvv) {
  cvv = trim(cvv)

  if (cvv === '') {
    alert('Please enter card cvv number.')
    return false
  } else if (cvv.length !== 3) {
    alert('Please enter 3-digit Card CVV Number.')
    return false
  } else {

    const iChars = '0123456789'
    for (let i = 0; i < cvv.length; i++) {
      if (iChars.indexOf(cvv.charAt(i)) === -1) {
        alert('Only numeric values are allowed in Card CVV Number.')
        return false
      }
    }
  }

  return true
}

function validateCcExpiration (month, year) {
  if (month === '') {
    alert('Please select expiry month.')
    return false
  }
  else if (year === '') {
    alert('Please select expiry year.')
    return false
  }
  if (month !== '' && year !== '') {
    const myDate = new Date()
    const today = new Date()
    myDate.setFullYear(year, month, 0)

    if (today > myDate) {
      alert('Please enter expiry date greater than current date.')
      return false
    }

    return true
  }

  return false
}

function isTestCard(ccNumber){
  const testCards = JSON.parse(document.formCompleteOrder.testCards.value)
  for (const card of testCards){
    if(card === calcMD5(ccNumber)){
      return true;
    }
  }
  return false;
}

function validateCC () {
  const ccNumToValidate = trim(document.formCompleteOrder.cardNumber.value);
  const errorDiv = document.getElementById('ccErrorDiv');
  const isCCErrorExists = document.getElementById('isCCErrorExists');
  const ccErrorMsg = errorDiv.innerHTML;

  if (isTestCard(ccNumToValidate) === false && !luhnCheck(ccNumToValidate)) {
    errorDiv.innerHTML = 'Invalid Card Number';
    errorDiv.classList.remove('hide');
    isCCErrorExists.value = 'yes';

    return false;
  }

  if (isNaN(ccNumToValidate)) {
    errorDiv.innerHTML = 'not a number-Please enter a valid credit card number.';
    errorDiv.classList.remove('hide');
    isCCErrorExists.value = 'yes';
  } else if (ccNumToValidate.length < 16) {
    errorDiv.innerHTML = 'Please enter 16-digit credit card number.';
    errorDiv.classList.remove('hide');
    isCCErrorExists.value = 'yes';
  } else {

    if (ccErrorMsg != 'Prepaid cards not accepted, please try different card') {
      errorDiv.innerHTML = '';
      errorDiv.classList.add('hide');
      isCCErrorExists.value = 'no';
    }
  }
}

/**
 *
 * @param url
 */
function openWindow (url) {
  const width = screen.availWidth / 2
  const height = screen.availHeight / 2
  const left = parseInt(width - (width / 2), 10)
  const top = parseInt(height - (height / 2), 10)
  const windowFeatures = `width=${width},height=${height},status,resizable,left=${left},top=${top},screenX=${left},screenY=${top},scrollbars=yes`
  window.open(url, '', windowFeatures)
}

/**
 * @param passwordElement
 * @param confirmPasswordElement
 * @returns {boolean}
 */
function validateConfirmPassword (passwordElement, confirmPasswordElement) {
  const password = document.getElementById(passwordElement)
  const confirmPassword = document.getElementById(confirmPasswordElement)

  if (password.value !== confirmPassword.value) {
    alert('Password and confirm password must be same')
    confirmPassword.focus()

    return false
  }

  return true
}

function submitUserDataForm () {
  const phone = document.querySelector('#phone')
  const phoneNumber = document.querySelector('#phoneNumber')
  const userDataForm = document.getElementById('userDataForm')

  const phoneValue = phone.value.replace(/[^\d]/g, '')

  if (phoneValue.length !== 10 && phoneValue.length !== 0) {
    alert('Please enter a valid phone number')
    phone.focus()

    return false
  }

  phoneNumber.value = phoneValue
  userDataForm.submit()
}

/**
 *
 * @param string
 * @returns {*}
 */
function removeSpaces(string) {
  return string.split(' ').join('');
}

function handleSubmitSearchFormBox() {
  var validatedVin = validateVin();

  if (validatedVin) {
    verifyVinNumber();
  }
  return false;
}
function validateVin() {
  const vinError = document.getElementById('vinError');
  const vinNumberField = document.getElementById('vinNumber');
  var vinNumber = removeSpaces(vinNumberField.value);
  const vinLength = vinNumber.length;

  vinError.innerText = '';
  if (vinNumber === '') {
    alert('Please enter vin number');
    vinNumberField.focus();
    return false;

  }
  if (vinLength != 17) {
    vinError.innerText = `The VIN must be 17 characters. You entered ${vinLength} characters.`;
    return false;
  }


  if (vinNumber !== '') {
    var regexp = /^[a-zA-Z0-9]+$/;
    var check = vinNumberField.value;
    if (check.search(regexp) == -1) {
      alert('Only numeric and letters values are allowed in vin to search');
      vinNumberField.focus();
      return false;
    }
  }
  return true;
}
function verifyVinNumber() {
  const CancelToken = axios.CancelToken;
  let source = CancelToken.source();

  let url = '/verify-vin-number';
  const vinNumber = document.getElementById('vinNumber').value;
  source = CancelToken.source();

  axios.post(url, { vinNumber }, {
    cancelToken: source.token,
  }).then(function(response) {
    var responseData = response.data;

    if (parseInt(responseData.status) === 200 && responseData.data.isValidVinNumber === 'yes') {
      document.getElementById('searchForm').submit();
    }
    if (parseInt(responseData.status) === 200 && responseData.data.isValidVinNumber === 'no') {
      const vinError = document.getElementById('vinError');
      vinError.innerText = 'The VIN entered is invalid. Please check and try again.';
    }
  }).catch(function(error) {
    // no need to print error here
  });
}
/**
 *
 * @param string
 * @returns {*}
 */
function cleanupVin(string) {
  var vinNumber = removeSpaces(trim(string));
  const inputElement = document.getElementById("vinNumber");

  var replaceCharObj = {
    i: 1,
    o: 0,
    q: 0,
    I: 1,
    O: 0,
    Q: 0,
  };

  vinNumber = vinNumber.replace(/i|o|q/gi, function(matched) {
    return replaceCharObj[matched];
  });
  inputElement.setAttribute("maxlength", "17");
  inputElement.setAttribute("onfocus", "removeErrorV12()");
  return vinNumber;
}

function handleSubmitPlateSearchFormBox() {
  return verifyPlateNumber()
}

function verifyVin() {
  const vinNumberField = document.getElementById('vinNumber')
  var vinNumber        = removeSpaces(vinNumberField.value);

  if (vinNumber === '') {
    alert("Please enter vin number");
    vinNumberField.focus();
    return false;

  }
  if (vinNumber !== "") {
    var regexp = /^[a-zA-Z0-9]+$/;
    var check  = vinNumberField.value;
    if (check.search(regexp) == -1) {
      alert('Only numeric and letters values are allowed in vin to search');
      vinNumberField.focus();
      return false;
    }
  }
  return true
}

function verifyPlateNumber() {
  const plateNumberField = document.getElementById('plateNumber')
  var plateNumber        = removeSpaces(plateNumberField.value);

  if (plateNumber === '') {
    alert("Please enter plate number");
    plateNumberField.focus();
    return false;

  }
  return true
}

function validatePasswordReminderForm () {
  const passwordReminderForm = document.passwordReminderForm

  if (!validateEmail(passwordReminderForm.reminderEmail.value)) {
    passwordReminderForm.reminderEmail.focus()
    return false
  }
}

function submitLoginForm() {
  const email = document.querySelector('#email');
  const password = document.querySelector('#password');
  const userLoginForm = document.getElementById('loginForm');

  if (!validateEmail(email.value)) {
    email.focus();
    return false;
  }

  if (trim(password.value) === '') {
    alert('Please enter password');
    password.focus();

    return false;
  }

  userLoginForm.submit();
}

const luhnCheck = num => {
  const arr = (num + '')
    .split('')
    .reverse()
    .map(x => parseInt(x));
  const lastDigit = arr.shift();
  let sum = arr.reduce(
    (acc, val, i) => (i % 2 !== 0 ? acc + val : acc + ((val *= 2) > 9 ? val - 9 : val)),
    0
  );
  sum += lastDigit;
  return sum % 10 === 0;
};
function removeCCError(){
  const errorDiv = document.getElementById('ccErrorDiv');
  const isCCErrorExists = document.getElementById('isCCErrorExists');

  errorDiv.innerHTML = '';
  errorDiv.classList.add('hide');
  isCCErrorExists.value = 'no';
}
function removeErrorV12() {
  const errorDiv = document.getElementById('vinError');
  const inputElement = document.getElementById("vinNumber");
  errorDiv.innerHTML = '';
  inputElement.removeAttribute("maxlength");
}
