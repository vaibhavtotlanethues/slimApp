<?php

namespace App\Traits;

use JtmSdk\Sdk;
use Odan\Session\SessionInterface;
use Psr\Http\Message\ServerRequestInterface;
use Slim\Routing\RouteContext;
use App\Services\VinNumberService;

trait Helper
{
    final public static function getIp()
    {
        $ipData   = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'];
        $ipValues = array_values(array_filter(explode(',', $ipData)));

        return reset($ipValues);
    }

    /**
     *
     * @param ServerRequestInterface $request
     * @param string                 $routeName
     *
     * @return string
     */
    public function getUrl(ServerRequestInterface $request, string $routeName): string
    {
        return RouteContext::fromRequest($request)->getRouteParser()->urlFor($routeName);
    }

    /**
     *
     * @param ServerRequestInterface $request
     * @param string                 $routeName
     *
     * @return string
     */
    public function getFullUrl(ServerRequestInterface $request, string $routeName): string
    {
        return RouteContext::fromRequest($request)->getRouteParser()->fullUrlFor($request->getUri(), $routeName);
    }

    /**
     *
     * @param ServerRequestInterface $request
     *
     * @return string
     */
    public function getCurrentRoute(ServerRequestInterface $request): string
    {
        return RouteContext::fromRequest($request)->getRoute()->getName();
    }

    /**
     * @param ServerRequestInterface $request
     * @param string                 $nextPage
     *
     * @return string
     */
    public function getNextPage(ServerRequestInterface $request, string $nextPage): string
    {
        $splitTestRoutes = $this->settings['splitTest'];
        $currentRoute    = $this->getCurrentRoute($request);

        if (isset($splitTestRoutes[$currentRoute])) {
            /**
             * will return ex. searchingForA for searchingFor
             */
            $nextPageSplit = $nextPage . strtoupper($splitTestRoutes[$currentRoute]);
            $nextPage      = isset($splitTestRoutes[$nextPageSplit]) ? $nextPageSplit : $nextPage;
        }

        return $this->getUrl($request, $nextPage);
    }

    /**
     * @param ServerRequestInterface $request
     *
     * @return string
     */
    public function getSplitTestVersion(ServerRequestInterface $request): string
    {
        $splitTestRoutes = $this->settings['splitTest'];
        $currentRoute    = $this->getCurrentRoute($request);
        return $splitTestRoutes[$currentRoute] ?? '';
    }

    /**
     * @param ServerRequestInterface $request
     * @param string                 $viewBasePath
     * @param string                 $file
     *
     * @return string
     */
    public function getCurrentPageView(ServerRequestInterface $request, string $viewBasePath, string $file): string
    {
        $viewDir = $this->getViewBaseDirectory($request);
        return "$viewDir/$viewBasePath/$file.twig";
    }

    /**
     * @param ServerRequestInterface $request
     *
     * @return string
     */
    public function getViewBaseDirectory(ServerRequestInterface $request): string
    {
        $splitTestRoutes = $this->settings['splitTest'];
        $currentRoute    = $this->getCurrentRoute($request);
        $splitTestDir    = '';
        if (isset($splitTestRoutes[$currentRoute])) {
            $splitTestDir = 'split-test' . strtoupper($splitTestRoutes[$currentRoute]);
        }
        return $splitTestDir;
    }

    /**
     * @param string|null $data
     *
     * @return array|null
     * @throws \JsonException
     */
    public function decodePaymentFormData(string $data = null): ?array
    {
        if ($data === null) {
            return null;
        }
        $decodedData = html_entity_decode($data);
        return json_decode($decodedData, true, 512, JSON_THROW_ON_ERROR);
    }

    /**
     * @param SessionInterface $session
     *
     * @return array
     */
    public function getFunnelDisplayText(SessionInterface $session): array
    {
        $isVinNumber   = true;
        $vinNumberData = $session->get('vinNumberData');
        $displayText   = $vinNumberData['vinNumber'] ?? '';
        if (!$displayText) {
            $isVinNumber     = false;
            $plateNumberData = $session->get('plateNumberData');
            $displayText     = $plateNumberData['plateNumber'] ?? '';
        }
        return ['displayText' => $displayText, 'isVinNumber' => $isVinNumber];
    }

    /**
     * @param SessionInterface $session
     * @param Sdk              $jtmSdk
     *
     * @return bool
     * @throws \JsonException
     */
    public function getVinNumberResponseData(SessionInterface $session, Sdk $jtmSdk): bool
    {
        $vinNumberData = $session->get('vinNumberData') ?? [];
        $vinNumber     = $vinNumberData['vinNumber'] ?? null;
        if (!$vinNumber) {
            return false;
        }

        $vinNumberData['vinNumberSearchType'] = self::VIN_SEARCH_TYPE;
        $vinNumberService                     = new VinNumberService();
        $vinNumberRequest                     = $vinNumberService->createDataRequest($vinNumberData);
        $sdkResponse                          = $jtmSdk->searchVinNumber($vinNumberRequest);
        $vinResponseData                      = [];
        $auctionCount                         = 0;
        if ($sdkResponse->getResponseCode() === self::STATUS_SUCCESS) {
            $vinNumberResponse                      = $sdkResponse->getVinNumberResponse();
            $vinResponseData['ownerCount']          = $vinNumberResponse->getOwnerCount();
            $vinResponseData['accidentCount']       = $vinNumberResponse->getAccidentHistoryCount();
            $vinResponseData['rentalUse']           = $vinNumberResponse->getRentalUse() ? "Yes" : "No";
            $vinResponseData['lastOdometerReading'] = $vinNumberResponse->getLastOdometerReading();
            foreach ($vinNumberResponse->vehicleHistory as $vehicleData) {
                if (isset($vehicleData['source']) && ($vehicleData['source'] === self::AUCTION_VALUE)) {
                    $auctionCount++;
                }
            }
            $vinResponseData['auctionData'] = $auctionCount;
            $vinResponseData['stateRecord'] = $vinNumberResponse->getLastTitleState() ?? "0";
        }
        $session->set('vinResponseData', $vinResponseData);

        return true;
    }

    /**
     * @return array
     */
    public function getMonthsYears(): array
    {
        $currentMonth = date('n');
        $currentYear  = (int)date('Y');

        $months = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'];
        $years  = range($currentYear, $currentYear + 15);

        return [
            'currentMonth' => $currentMonth,
            'currentYear'  => $currentYear,
            'months'       => $months,
            'years'        => $years,
        ];
    }
}
