<?php

namespace App\Controllers;

use App\Factory\LoggerFactory;
use App\Interfaces\StatusCode;
use App\Traits\Helper;
use JsonException;
use JtmSdk\Sdk;
use JtmSdk\Session\AddressData;
use JtmSdk\Session\BillingData;
use JtmSdk\Session\CreditCardData;
use JtmSdk\Services\LocationService;
use JtmSdk\Session\CriminalSearchData;
use JtmSdk\Session\DynamicData;
use JtmSdk\Session\SessionData;
use JtmSdk\Session\SessionFactory;
use JtmSdk\Session\UserData;
use JtmSdk\Session\VehicleSearchData;
use Monolog\Logger;
use Odan\Session\SessionInterface;
use Psr\Container\ContainerExceptionInterface;
use Psr\Container\ContainerInterface;
use Psr\Container\NotFoundExceptionInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Log\LoggerInterface;
use Slim\Views\Twig;

class BaseController implements StatusCode
{
    public array $location;

    use Helper;

    protected Twig             $view;
    protected SessionInterface $session;
    protected LoggerInterface  $logger;
    protected LocationService  $locationService;

    protected Sdk   $jtmSdk;
    protected array $settings;
    private string  $funnel;

    /**
     * @param ContainerInterface $container
     *
     * @throws ContainerExceptionInterface
     * @throws NotFoundExceptionInterface
     */
    public function __construct(ContainerInterface $container)
    {
        /** @var array $settings */
        $this->settings = $container->get('settings');

        /** @var Twig $view */
        $this->view = $container->get('view');

        /** @var SessionInterface $session */
        $this->session = $container->get(SessionInterface::class);

        /** @var Logger $this - >logger */
        $this->logger = $container->get(LoggerFactory::class);

        /** @var LocationService $locationService */
        $this->locationService = $container->get(LocationService::class);

        /** @var Sdk $jtmSdk */
        $this->jtmSdk = $container->get(Sdk::class);

        /**
         * testing
         */
        if ($_SERVER['QUERY_STRING'] === 'clear') {
            $this->clearSession(['dynamicData']);
        }
    }

    /**
     * @param array $keys
     *
     * @return void
     */
    public function clearSession(array $keys): void
    {
        foreach ($keys as $key) {
            if ($this->session->has($key)) {
                $this->session->remove($key);
            }
        }
    }

    /**
     * @eturn string
     */
    public function getFunnel(): string
    {
        return $this->funnel;
    }

    /**
     * @param string $funnel
     *
     * @return void
     */
    public function setFunnel(string $funnel): void
    {
        $this->funnel = $funnel;
    }

    /**
     * @throws JsonException
     */
    public function redirect(ResponseInterface $response, string $url, array $data = null): ResponseInterface
    {
        if (!$data) {
            $response
                ->getBody()
                ->write(json_encode($data, JSON_THROW_ON_ERROR));
        }

        return $response
            ->withStatus(self::STATUS_FOUND)
            ->withHeader('Location', $url);
    }

    /**
     * @return string
     */
    public function getSessionId(): string
    {
        return session_id();
    }

    /**
     * @return string
     */
    public function getToken(): string
    {
        $tokenResponse = $this->jtmSdk->generateWebToken();

        return $tokenResponse->getWebTokenResponse()->getWebToken();
    }

    /**
     * @return bool
     */
    public function isIndexFunnel(): bool
    {
        $funnelType = $this->session->get('funnelType') ?? null;

        return $funnelType === self::INDEX_FUNNEL;
    }

    /**
     * @param string $name
     *
     * @return AddressData|BillingData|CreditCardData|CriminalSearchData|DynamicData|SessionData|UserData|VehicleSearchData|null
     */
    public function getSession(string $name)
    {
        $data = $this->session->get($name) ?? [];
        return (new SessionFactory())->getSessionObject($name, $data);
    }

    /**
     * @param string $name
     * @param array  $values
     *
     * @return void
     */
    public function updateSession(string $name, array $values): void
    {
        /** @var AddressData|BillingData|CreditCardData|DynamicData|SessionData|UserData $session */
        $session = $this->getSession($name);

        $this->session->set($name, array_merge($session->toArray(), $values));
    }

    /**
     * @param ServerRequestInterface $request
     * @param string                 $url
     *
     * @return string
     */
    public function getRedirectUrlWithFullStory(ServerRequestInterface $request, string $url): string
    {
        $cookies = $request->getCookieParams();
        $fsUid   = isset($cookies['fs_uid']) ? urlencode($cookies['fs_uid']) : null;
        $fs      = $fsUid ? "?fs_uid={$fsUid}" : '';

        return $url . $fs;
    }

}
