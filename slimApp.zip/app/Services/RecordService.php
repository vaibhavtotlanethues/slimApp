<?php

namespace App\Services;

use App\Traits\Helper;
use JtmSdk\Requests\CardRequest;

class RecordService
{
    use Helper;
    /**
     * @param array $requestBody
     *
     * @return CardRequest
     */
    public function createCardRequest(array $requestBody): CardRequest
    {
        $cardRequest = new CardRequest();
        $cardRequest->setCardNumber($requestBody['cardNumber']);
        $cardRequest->setFirstName($requestBody['firstName'] ?? null);
        $cardRequest->setLastName($requestBody['lastName'] ?? null);
        $cardRequest->setEmail($requestBody['email'] ?? null);
        $cardRequest->setIp(self::getIp());
        $cardRequest->setSiteMarker($_ENV['SITE_MARKER']);

        return $cardRequest;
    }
}
