<?php

namespace App\Services;

use App\Traits\Helper;
use JtmSdk\Requests\VinNumberRequest;

class VinNumberService
{
    use Helper;

    /**
     * @param array $requestBody
     *
     * @return array
     */
    public function validateFormParams(array $requestBody): array
    {
        $requiredParams = ['vinNumber', 'redirectBack'];

        $errors = [];
        foreach ($requiredParams as $key) {
            if (empty($requestBody[$key])) {
                $errors[$key] = 'form-error';
            }
        }

        return $errors;
    }

    /**
     * @param array $requestBody
     *
     * @return VinNumberRequest
     */
    public function createDataRequest(array $requestBody): VinNumberRequest
    {
        $vinNumberRequest = new VinNumberRequest();
        $vinNumberRequest->setVinNumber($requestBody['vinNumber']);
        $vinNumberRequest->setIp(self::getIp());
        $vinNumberRequest->setSiteMarker($_ENV['SITE_MARKER']);
        $vinNumberRequest->setVinNumberSearchType($requestBody['vinNumberSearchType'] ?? null);

        return $vinNumberRequest;
    }
}
