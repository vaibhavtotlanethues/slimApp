<?php

use App\Controllers\BaseController;
use App\Controllers\VehicleFunnelController;
use App\Controllers\HomeController;
use App\Controllers\IndexFunnelController;
use App\Controllers\PlateFunnelController;
use DI\Container;
use Psr\Container\ContainerInterface;

/** @var ContainerInterface $container */
$app       = $app ?? null;

/** @var Container $container */
$container = $app->getContainer();

$container->set(BaseController::class, function (ContainerInterface $container) {
    return new App\Controllers\BaseController($container);
});

$container->set(VehicleFunnelController::class, function (ContainerInterface $container) {
    return new App\Controllers\VehicleFunnelController($container);
});

$container->set(HomeController::class, function (ContainerInterface $container) {
    return new App\Controllers\HomeController($container);
});

$container->set(IndexFunnelController::class, function (ContainerInterface $container) {
    return new App\Controllers\IndexFunnelController($container);
});

$container->set(PlateFunnelController::class, function (ContainerInterface $container) {
    return new App\Controllers\PlateFunnelController($container);
});