<?php

namespace App\Services;

use App\Traits\Helper;
use JtmSdk\Requests\UserPhoneRequest;
use JtmSdk\Requests\UserRequest;

/**
 * Class UserService
 *
 * @package App\Services
 */
class UserService
{
    use Helper;

    /**
     * @param array $requestBody
     *
     * @return array
     */
    public function validateFormParams(array $requestBody): array
    {
        $requiredParams = ['email', 'password', 'confirmPassword'];

        $errors = [];
        foreach ($requiredParams as $key) {
            if (empty($requestBody[$key])) {
                $errors[$key] = 'form-error';
            }
        }

        return $errors;
    }

    /**
     * @param string $password
     * @param string $confirmPassword
     *
     * @return bool
     */
    private function validateUserPassword(string $password, string $confirmPassword): bool
    {
        return $password === $confirmPassword;
    }

    /**
     * @param string|null $phone
     *
     * @return bool
     */
    private function validateUserPhone(string $phone = null): bool
    {
        $validPhone  = preg_replace('/\D/', '', $phone);
        $phoneLength = strlen($validPhone);

        return $phoneLength === 10 || $phoneLength === 0;
    }

    /**
     * @param UserRequest $userRequest
     *
     * @return array
     */
    public function validateUserData(UserRequest $userRequest): array
    {
        $errors          = $this->validateFormParams($userRequest->toArray());
        $isValidPassword = $this->validateUserPassword($userRequest->getPassword(), $userRequest->getConfirmPassword());
        if (!$isValidPassword) {
            $errors['password'] = 'form-error';
        }

        return $errors;
    }

    /**
     * @param array $requestBody
     * @param bool  $isRecurring
     *
     * @return UserRequest
     */
    public function createUserDataRequest(array $requestBody, bool $isRecurring = false): UserRequest
    {
        $userRequest = new UserRequest();
        $userRequest->setUuid($requestBody['uuid'] ?? null);
        $userRequest->setPassword($requestBody['password'] ?? null);
        $userRequest->setConfirmPassword($requestBody['confirmPassword'] ?? null);
        $userRequest->setFirstName($requestBody['firstName'] ?? null);
        $userRequest->setLastName($requestBody['lastName'] ?? null);
        $userRequest->setEmail($requestBody['email'] ?? null);
        $userRequest->setApproved($requestBody['approved'] ?? false);
        $userRequest->setSiteMarker($requestBody['siteMarker'] ?? null);
        $userRequest->setSubMarker($requestBody['siteMarker'] ?? null);
        $userRequest->setUpsellPage($requestBody['upsellType'] ?? null);
        $userRequest->setIp(self::getIp());

        /**
         * set user location data here
         * we are calling this "createUserDataRequest()" at multiple places
         * we need this location data only at the time of userCreation
         */
        if (isset($requestBody['userLocationData'])) {
            $userLocationData = $requestBody['userLocationData'];
            $userRequest->setCountry($userLocationData['country'] ?? null);
            $userRequest->setState($userLocationData['state'] ?? null);
            $userRequest->setCity($userLocationData['city'] ?? null);
            $userRequest->setAddress($userLocationData['address'] ?? null);
            $userRequest->setZipCode($userLocationData['zipCode'] ?? null);
        }

        $billingService    = new BillingService();
        $processingDetails = $billingService->getTransactionProcessingDetails($isRecurring);

        $userRequest->setProductId($processingDetails['productId']);

        return $userRequest;
    }

    /**
     * @param array $requestBody
     *
     * @return array
     */
    public function validateUserPhoneData(array $requestBody): array
    {
        $errors       = [];
        $isValidPhone = $this->validateUserPhone($requestBody['phone']);

        if (!$isValidPhone) {
            $errors['phone'] = 'form-error';
        }

        return $errors;
    }

    /**
     * @param array $requestBody
     *
     * @return UserPhoneRequest
     */
    public function createUserPhoneRequest(array $requestBody): UserPhoneRequest
    {
        $request = new UserPhoneRequest();
        $request->setCustomerId($requestBody['uuid']);
        $request->setPhone($requestBody['phone']);
        $request->setSiteMarker($_ENV['SITE_MARKER']);
        $request->setUpsell('yes');

        return $request;
    }

    /**
     * @param $requestBody
     *
     * @return array
     */
    public function validateLoginParams($requestBody)
    {
        $requiredParams = ['email', 'password'];

        $errors = [];
        foreach ($requiredParams as $key) {
            if (empty($requestBody[$key])) {
                $errors[$key] = 'form-error';
            }
        }
        return $errors;
    }
}
