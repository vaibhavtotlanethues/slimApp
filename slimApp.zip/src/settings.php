<?php

use Monolog\Logger;

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

$db = [
    'driver'    => '',
    'host'      => '',
    'username'  => '',
    'password'  => '',
    'charset'   => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
    'prefix'    => ''
];

return [
    'displayErrorDetails'               => $_ENV['APP_ENV'] !== 'prod', // set to false in production
    'addContentLengthHeader'            => false, // Allow the web server to send the content-length header
    'determineRouteBeforeAppMiddleware' => true,
    'debug'                             => true,
    'public'                            => __DIR__ . '/../public',

    'renderer' => [
        'template_path' => __DIR__ . '/../templates/',
    ],

    'main_db' => array_merge($db, ['database' => $_ENV['DB_DATABASE'] ?? '']),

    'maps' => [
        'key' => ''
    ],

    'session' => [
        'name'         => $_ENV['SESSION_NAME'],
        'cache_expire' => 0,
    ],

    'logger'           => [
        'url'   => $_ENV['LOGGER_URL'],
        'port'  => $_ENV['LOGGER_PORT'],
        'name'  => 'carhistory.online.' . strtoupper($_ENV['APP_ENV']),
        'level' => Logger::DEBUG,
    ],
    'locationDefaults' => [
        'title'       => 'Public Vehicle History Records',
        'country'     => 'US',
        'countryName' => 'United States',
        'state'       => 'US',
        'stateName'   => '',
        'city'        => '',
        'zipCode'     => '',
        'stateLink'   => '',
        'rightTitle'  => '',
    ],
    'splitTest'        => [
        'searchVinNumberV1'  => 'V1',
        'vehicleV1'          => 'V1',
        'checkingV1'         => 'V1',
        'confirmV1'          => 'V1',
        'downloadingV1'      => 'V1',
        'downloadedV1'       => 'V1',
        'previewV1'          => 'V1',
        'packageV1'          => 'V1',
        'accountV1'          => 'V1',
        'searchVinNumberV2'  => 'V2',
        'vehicleV2'          => 'V2',
        'checkingV2'         => 'V2',
        'confirmV2'          => 'V2',
        'downloadingV2'      => 'V2',
        'downloadedV2'       => 'V2',
        'previewV2'          => 'V2',
        'packageV2'          => 'V2',
        'accountV2'          => 'V2',        
        'searchVinNumberV3'  => 'V3',
        'vehicleV3'          => 'V3',
        'checkingV3'         => 'V3',
        'confirmV3'          => 'V3',
        'downloadingV3'      => 'V3',
        'downloadedV3'       => 'V3',
        'previewV3'          => 'V3',
        'packageV3'          => 'V3',
        'accountV3'          => 'V3',
        'searchVinNumberV15' => 'V15',
        'vehicleV15'         => 'V15',
        'checkingV15'        => 'V15',
        'confirmV15'         => 'V15',
        'downloadingV15'     => 'V15',
        'downloadedV15'      => 'V15',
        'previewV15'         => 'V15',
        'packageV15'         => 'V15',
        'accountV15'         => 'V15',
        'searchVinNumberV4'  => 'V4',
        'vehicleV4'          => 'V4',
        'checkingV4'         => 'V4',
        'confirmV4'          => 'V4',
        'downloadingV4'      => 'V4',
        'downloadedV4'       => 'V4',
        'previewV4'          => 'V4',
        'packageV4'          => 'V4',
        'accountV4'          => 'V4',
        'billingV4'          => 'V4',
        'billingPostV4'      => 'V4',
        'vehicleName'        => 'NAME',
    ]
];
