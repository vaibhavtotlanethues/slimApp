<?php

namespace App\Services;

use JtmSdk\Requests\EmailRequest;

/**
 * Class EmailService
 *
 * @package App\Services
 */
class EmailService
{

    /**
     *
     * @param array $requestBody
     *
     * @return EmailRequest
     */
    public function createPasswordReminderFormRequest(array $requestBody): EmailRequest
    {
        $emailRequest = new EmailRequest();
        $emailRequest->setSiteMarker($requestBody['siteMarker']);
        $emailRequest->setEmail($requestBody['reminderEmail']);

        return $emailRequest;
    }

    /**
     *
     * @param array $requestBody
     *
     * @return array
     */
    public function validatePasswordReminderForm(array $requestBody): array
    {
        $requiredFields = ['reminderEmail', 'redirectUrl'];
        $errors         = [];
        foreach ($requestBody as $key => $value) {
            if (empty($value) && in_array($key, $requiredFields, false)) {
                $errors[$key] = "form-error";
            }
        }
        return $errors;
    }

}
