<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header('Cache-Control: no cache');

use App\Factory\LoggerFactory;
use Dotenv\Dotenv;
use Illuminate\Database\Capsule\Manager;
use Monolog\Logger;
use Odan\Session\Middleware\SessionMiddleware;
use Odan\Session\PhpSession;
use Odan\Session\SessionInterface;
use Psr\Container\ContainerInterface;
use Psr\Http\Message\ServerRequestInterface;
use Slim\Exception\HttpMethodNotAllowedException;
use Slim\Exception\HttpNotFoundException;
use Slim\Factory\AppFactory;
use Slim\Views\Twig;
use Slim\Views\TwigMiddleware;
use DI\Container;
use Twig\Extension\DebugExtension;
use JtmSdk\Sdk;
use JtmSdk\Config\LocationConfig;
use JtmSdk\Services\LocationService;

if (PHP_SAPI === 'cli' || PHP_SAPI === 'fpm-fcgi') {
    $url  = parse_url($_SERVER['REQUEST_URI']);
    $file = __DIR__ . $url['path'];
    if (is_file($file)) {
        return false;
    }
}

// server should keep session data for AT LEAST 5 hours
ini_set('session.gc_maxlifetime', 18000);

// each client should remember their session id for EXACTLY 5 hours
session_set_cookie_params(18000);

require __DIR__ . '/../vendor/autoload.php';

// fix the secure environment detection if behind an AWS ELB
if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
    $_SERVER['HTTPS']          = 'on';
    $_SERVER['SERVER_PORT']    = '443';
    $_SERVER['REQUEST_SCHEME'] = 'https';
}

$dotenv = Dotenv::createUnsafeImmutable(__DIR__ . '/../');
$dotenv->load();

$settings = require __DIR__ . '/../src/settings.php';

// Create Container using PHP-DI
$container = new Container();

$container->set('environment', function () {

    $server = $_SERVER;

    // fix the secure environment detection if behind an AWS ELB
    if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
        $server['HTTPS'] = 'on';
        $server['SERVER_PROTOCOL'] = 'HTTP/2.0';
        $server['REQUEST_SCHEME'] = 'https';
    }

    return new Environment($server);
});


$container->set('settings', $settings);

$container->set(LocationService::class, static function (ContainerInterface $container) {
    $settings        = $container->get('settings');
    $defaultLocation = $settings['locationDefaults'];

    $locationConfig = new LocationConfig();
    $locationConfig->setTitle($defaultLocation['title']);
    $locationConfig->setCountry($defaultLocation['country']);
    $locationConfig->setCountryName($defaultLocation['countryName']);
    $locationConfig->setState($defaultLocation['state']);
    $locationConfig->setStateName($defaultLocation['stateName']);
    $locationConfig->setCity($defaultLocation['city']);
    $locationConfig->setZipCode($defaultLocation['zipCode']);
    $locationConfig->setStateLink($defaultLocation['stateLink']);
    $locationConfig->setRightTitle($defaultLocation['rightTitle']);

    return new LocationService($locationConfig);
});

$container->set(Sdk::class, static function (ContainerInterface $container) {
    return new Sdk($_ENV['API_BASE_PATH']);
});

// Set container to create App with on AppFactory
AppFactory::setContainer($container);

// database
$capsule = new Manager();
$capsule->addConnection($container->get('settings')['main_db'], 'main_db');
$capsule->setAsGlobal();
$capsule->bootEloquent();

$app = AppFactory::create();

$container->set(SessionInterface::class, static function (ContainerInterface $container) {
    $settings = $container->get('settings');
    $session  = new PhpSession();
    $session->setOptions((array)$settings['session']);

    return $session;
});

$container->set(SessionMiddleware::class, static function (ContainerInterface $container) {
    return new SessionMiddleware($container->get(SessionInterface::class));
});

$app->add(SessionMiddleware::class);
$app->addRoutingMiddleware();

// Create Twig
try {
    $twig = Twig::create(__DIR__ . '/../resources/views', [
        'cache' => false, // __DIR__ . '/../public/cache',
        'debug' => true,
    ]);

    require __DIR__ . '/../src/twig.php';

    $twig->addExtension(new DebugExtension());

    // Add Twig-View Middleware
    $app->add(TwigMiddleware::create($app, $twig));

    $container->set('view', $twig);
} catch (\Twig\Error\LoaderError $e) {
    // Error loading twig templates
    // var_dump($e->getMessage());
}

$container->set(LoggerFactory::class, static function (ContainerInterface $container) {
    $settings       = $container->get('settings');
    $loggerSettings = $settings['logger'];

    $output    = "%channel%.%level_name%: %message%";
    $formatter = new Monolog\Formatter\LineFormatter($output);

    $logger        = new Monolog\Logger($loggerSettings['name']);
    $syslogHandler = new Monolog\Handler\SyslogUdpHandler($loggerSettings['url'], $loggerSettings['port']);

    $syslogHandler->setFormatter($formatter);
    $logger->pushHandler($syslogHandler);

    return $logger;
});

$customErrorHandler = function (
    ServerRequestInterface $request,
    \Throwable $exception
) use ($app, $container) {
    $response = $app->getResponseFactory()->createResponse();

    $code = 200;
    $exceptionCode = $exception->getCode();
    if ($exceptionCode === 403 || $exceptionCode === 404) {
        $code = $exceptionCode;
    }

    /** @var Twig $view */
    $view = $container->get('view');

    $response = $response->withStatus($code);

    return $view->render($response, '404.twig', ['code' => $code]);
};

/** @var Logger $logger */
$logger = $app->getContainer()->get(LoggerFactory::class);

$errorMiddleware = $app->addErrorMiddleware(true, true, true, $logger);
$errorMiddleware->setDefaultErrorHandler($customErrorHandler);

// Register dependencies
require __DIR__ . '/../src/dependencies.php';

// Register routes
require __DIR__ . '/../src/routes.php';

$app->run();
