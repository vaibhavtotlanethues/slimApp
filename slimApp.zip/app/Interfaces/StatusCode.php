<?php

namespace App\Interfaces;

interface StatusCode
{
    public const STATUS_SUCCESS      = 200;
    public const STATUS_NOT_FOUND    = 404;
    public const STATUS_FOUND        = 302;
    public const STATUS_ZERO         = 0;
    public const INDEX_FUNNEL        = 'indexFunnel';
    public const VEHICLE_FUNNEL      = 'vehicleFunnel';
    public const PLATE_FUNNEL        = 'plateFunnel';
    public const CARD_ALREADY_EXISTS = 'card_already_exists';
    public const HARD_DECLINED       = 'hard_declined';
    public const PREPAID_CARD_ERROR  = 'Prepaid cards not accepted, please try different card';
    public const TITLES              = [
        self::INDEX_FUNNEL => '1 Index Lookup Report',
    ];
    public const VIN_SEARCH_TYPE     = 'vehicle_history';
    public const VIN_SUCCESS_CODE    = 0;
    public const AUCTION_VALUE       = 'AUCTION';
}
