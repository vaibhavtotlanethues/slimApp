<?php

namespace App\Services;

use App\Traits\Helper;
use JtmSdk\Requests\PlateNumberRequest;

class PlateNumberService
{
    use Helper;

    /**
     * @param array $requestBody
     *
     * @return array
     */
    public function validateFormParams(array $requestBody): array
    {
        $requiredParams = ['plateNumber', 'state'];

        $errors = [];
        foreach ($requiredParams as $key) {
            if (empty($requestBody[$key])) {
                $errors[$key] = 'form-error';
            }
        }

        return $errors;
    }

    /**
     * @param array $requestBody
     *
     * @return PlateNumberRequest
     */
    public function createDataRequest(array $requestBody): PlateNumberRequest
    {
        $plateNumberRequest = new PlateNumberRequest();
        $plateNumberRequest->setSiteMarker($_ENV['SITE_MARKER']);
        $plateNumberRequest->setPlateNumber($requestBody['plateNumber']);
        $plateNumberRequest->setState($requestBody['state']);
        $plateNumberRequest->setIp(self::getIp());

        return $plateNumberRequest;
    }
}
