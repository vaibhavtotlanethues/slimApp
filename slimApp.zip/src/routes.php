<?php

use App\Controllers\HomeController;
use App\Controllers\VehicleFunnelController;
use App\Controllers\IndexFunnelController;
use App\Controllers\PlateFunnelController;

$app = $app ?? null;
$app->addBodyParsingMiddleware();

$app->get('/', IndexFunnelController::class . ':index')->setName('index');
