<?php

namespace App\Services;

use App\Interfaces\StatusCode;
use App\Traits\Helper;
use JtmSdk\Requests\TransactionRequest;

/**
 * Class BillingService
 *
 * @package App\Services
 */
class BillingService implements StatusCode
{
    use Helper;

    /**
     * @param array $requestBody
     *
     * @return array
     */
    public function validateBillingForm(array $requestBody): array
    {
        $user        = ['firstName', 'lastName', 'email'];
        $transaction = ['cardNumber', 'expMonth', 'expYear', 'cardCvvNo'];

        $requiredParams = array_merge($user, $transaction);
        $errors         = [];
        foreach ($requiredParams as $key) {
            if (empty($requestBody[$key])) {
                $errors[$key] = "form-error";
            }
        }

        return $errors;
    }

    /**
     * @param array $requestBody
     * @param bool  $isRecurring
     *
     * @return TransactionRequest
     */
    public function createTransactionRequest(array $requestBody, bool $isRecurring): TransactionRequest
    {
        $transactionObj = new TransactionRequest();
        $transactionObj->setFirstName($requestBody['firstName']);
        $transactionObj->setLastName($requestBody['lastName'] ?? null);
        $transactionObj->setSiteMarker($requestBody['siteMarker']);
        $transactionObj->setUserId($requestBody['userId'] ?? null);
        $transactionObj->setCardNumber($requestBody['cardNumber'] ?? null);
        $transactionObj->setExpMonth($requestBody['expMonth'] ?? null);
        $transactionObj->setExpYear($requestBody['expYear'] ?? null);
        $transactionObj->setCvv($requestBody['cardCvvNo'] ?? null);
        $transactionObj->setEmail($requestBody['email']);
        $transactionObj->setIp(self::getIp());
        $transactionObj->setVerifyDuplicate((int)$requestBody['verifyDuplicate']);
        $transactionObj->setIs3dsTransaction((int)($requestBody['is3dsTransaction'] ?? 0));

        $processingDetails = $this->getTransactionProcessingDetails($isRecurring);
        if ($requestBody['funnelType'] === self::INDEX_FUNNEL) {
            $processingDetails['productTitle'] = self::TITLES[self::INDEX_FUNNEL];
        }

        $transactionObj->setAmount($processingDetails['amount']);
        $transactionObj->setProductPrice($processingDetails['amount']);
        $transactionObj->setTotalPrice($processingDetails['amount']);
        $transactionObj->setMerchantProductId($processingDetails['merchantProductId']);
        $transactionObj->setMerchantSiteId($processingDetails['merchantSiteId']);
        $transactionObj->setProductTitle($processingDetails['productTitle']);
        $transactionObj->setProductId($processingDetails['productId']);
        $transactionObj->setIsRecurring($processingDetails['recurring']);
        $transactionObj->setRecurringStartDate($processingDetails['recurringStart']);
        $transactionObj->setRecurringCount($processingDetails['recurringCount']);
        $transactionObj->setRecurringFrequency($processingDetails['recurringFrequency']);
        $transactionObj->setSearchCredits($processingDetails['searchCredits']);

        return $transactionObj;
    }

    /**
     * @param bool $isRecurring
     *
     * @return array
     */
    public function getTransactionProcessingDetails(bool $isRecurring): array
    {
        $data = [
            'recurring' => [
                'amount'             => 28.95,
                'merchantProductId'  => 203,
                'merchantSiteId'     => 3,
                'productTitle'       => '1 Lookup Report',
                'productId'          => 1,
                'recurring'          => 1,
                'recurringStart'     => 30,
                'recurringCount'     => 23,
                'searchCredits'      => 30,
                'recurringFrequency' => 'MONTHLY',
            ],
            'default'   => [
                'amount'             => 1.00,
                'merchantProductId'  => 203,
                'merchantSiteId'     => 3,
                'productTitle'       => '1 Lookup Report',
                'productId'          => 2,
                'recurring'          => 0,
                'recurringStart'     => 0,
                'recurringCount'     => 0,
                'searchCredits'      => 1,
                'recurringFrequency' => '',
            ],
        ];

        return $isRecurring ? $data['recurring'] : $data['default'];
    }

    /**
     * @param array $data
     *
     * @return array
     */
    public function getFirstNameLastName(array $data): array
    {
        $firstName = $data['firstName'] ?? null;
        $lastName  = $data['lastName'] ?? null;

        if ($firstName && $lastName) {
            return [
                'firstName' => trim($firstName),
                'lastName'  => trim($lastName),
            ];
        }

        if ($firstName) {
            $nameParts = explode(" ", trim($firstName));
            $firstName = array_shift($nameParts);

            $lastName = trim(implode(' ', $nameParts));
            $lastName = $lastName !== '' ? $lastName : $firstName;
        }

        return [
            'firstName' => $firstName,
            'lastName'  => $lastName,
        ];
    }
}
